<?php

/**
 * Created by PhpStorm.
 * User: NhatLe
 * Date: 27-May-17
 * Time: 22:32
 */
class ProductModel extends N_Model
{
    public $code;
    public $name;
    public $alias;
    public $image;
    public $price;
    public $status;
    public $desc;
    public $detail;
    public $view;
    public $sold;
    public $id_cate;

    public function __construct()
    {
        $this->connect();
    }

    public function __destruct()
    {
        $this->disconnect();
    }

    public function getListProduct() {
        $sql = "SELECT * FROM `fs_product`";
        $this->execute($sql);
        return $this->getResult();
    }

    public function getListProductLimit($page = 1, $limit = 10) {
        $pos = ($page - 1) * $limit;
        $sql = "SELECT * FROM `fs_product` LIMIT $pos,$limit";
        $this->execute($sql);
        return $this->getResult();
    }

    public function getListProductByCate($id) {
        $sql = "SELECT * FROM `fs_product` WHERE `id_cate` = $id";
        $this->execute($sql);
        return $this->getResult();
    }

    public function getListProductLimitByCate($id, $page = 1, $limit = 10) {
        $pos = ($page - 1) * $limit;
        $sql = "SELECT * FROM `fs_product` WHERE `id_cate` = $id LIMIT $pos,$limit";
        $this->execute($sql);
        return $this->getResult();
    }

    public function getProductByCode($code) {
        $sql = "SELECT * FROM `fs_product` WHERE `code` = '$code'";
        $this->execute($sql);
        return $this->getResult();
    }

}