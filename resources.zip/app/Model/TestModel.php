<?php

/**
 * Created by PhpStorm.
 * User: NhatLe
 * Date: 25-May-17
 * Time: 22:34
 */
class TestModel extends N_Model
{
    public function __construct()
    {
       $this->connect();
       $sql = "SELECT * FROM fs_district";
       var_dump($this->execute($sql));
       print_r($this->getResult());
    }
}