<?php

/**
 * Created by PhpStorm.
 * User: NhatLe
 * Date: 27-May-17
 * Time: 15:24
 */
class CategoryModel extends N_Model
{
    public function __construct()
    {
        $this->connect();
    }

    public function __destruct()
    {
        $this->disconnect();
    }
    public function getListCate() {
        $sql = "SELECT * FROM `fs_category`";
        $this->execute($sql);
        return $this->getResult();
    }

    public function getListCateLimit($page = 1, $limit = 10) {
        $pos = ($page - 1) * $limit;
        $sql = "SELECT * FROM `fs_category` ORDER BY `id` DESC LIMIT $pos,$limit";
        $this->execute($sql);
        return $this->getResult();
    }

    public function getListCateById($id) {
        $sql = "SELECT * FROM `fs_category` WHERE `id_parent` = $id";
        $this->execute($sql);
        return $this->getResult();
    }

    public function getListCateLimitById($id, $page = 1, $limit = 10) {
        $pos = ($page - 1) * $limit;
        $sql = "SELECT * FROM `fs_category` WHERE `id_parent` = $id ORDER BY `id` DESC LIMIT $pos,$limit";
        $this->execute($sql);
        return $this->getResult();
    }

    public function getListCateParent() {
        $sql = "SELECT * FROM `fs_category` WHERE `id_parent` = 0";
        $this->execute($sql);
        return $this->getResult();
    }

    public function getCateByName($name) {
        $sql = "SELECT * FROM `fs_category` WHERE `name` = '$name'";
        $this->execute($sql);
    }

    public function getCateById($id) {
        $sql = "SELECT * FROM `fs_category` WHERE `id` = '$id'";
        $this->execute($sql);
        return $this->getResult();
    }
}