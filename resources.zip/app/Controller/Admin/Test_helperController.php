<?php

/**
 * Created by PhpStorm.
 * User: NhatLe
 * Date: 25-May-17
 * Time: 14:50
 */
class Test_helperController extends N_Controller
{
    public function indexAction()
    {
        echo '<h1>Index Action</h1>';

        echo ucwords(mb_strtolower('LÊ QUÍ NHẤT'));
        $this->helper->load("String");
        echo changeTitle('Lê Quí Nhất');
        print_r($this);
    }
}