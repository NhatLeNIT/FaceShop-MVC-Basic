<?php
/**
 * Created by PhpStorm.
 * User: NhatLe
 * Date: 26-May-17
 * Time: 22:52
 */
return array(
    'controller_default'   => 'Login',
    'action_default'          => 'index'
);