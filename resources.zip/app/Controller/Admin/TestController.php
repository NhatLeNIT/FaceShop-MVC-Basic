<?php

/**
 * Created by PhpStorm.
 * User: NhatLe
 * Date: 25-May-17
 * Time: 12:41
 */
class TestController extends N_Controller
{
    public function indexAction()
    {
        echo '<h1>Index Action</h1>';
        $this->library->load("Test");
        $b = new TestLibrary();
        $b->test();
//        $this->library->load("Pagination");
//        $a = new PaginationLibrary();
//        $a->paginate();
//       $b->test1();
//        print_r($this);
//        $this->model->load("Test");
//        $c = new TestModel();

        $this->library->load('Mail');
        $mail = new MailLibrary();
        $mail->init('it.quinhat', 'ydgamumoyslqapjk');
        $check = $mail->sendMail('admin@nhatle.net', 'quinhatpy@gmail.com', "Test Mail FaceShop", 'Nội dung');
        if($check) echo "Gửi thành công";
        else echo "Gửi thất bại";
    }

    public function detailAction()
    {
        echo '<h1>Detail Action</h1>';
    }
}