<?php

/**
 * Created by PhpStorm.
 * User: NhatLe
 * Date: 25-May-17
 * Time: 15:02
 */
class Test_viewController extends N_Controller
{
    public function indexAction()
    {
        // Load view
        $this->view->load('testview', 'Admin');

        // Show view
//        $this->view->show();
    }

    public function parameterAction()
    {
        $data = array(
            'title' => 'test truyền tham số',
            'arr' => ["anh","Nhất","Pro"]
            // Load view
        );
        $this->view->load('testViewCoThamSo', 'Admin', $data);
        // Show view
        $this->view->show();
    }
}