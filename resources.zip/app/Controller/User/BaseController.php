<?php

/**
 * Created by PhpStorm.
 * User: NhatLe
 * Date: 28-May-17
 * Time: 19:08
 */
class BaseController extends N_Controller
{
    protected $data = array();
    public function __construct()
    {
        parent::__construct();
        $this->model->load('Category');
        $cateObj = new CategoryModel();
        $this->data['dataCate'] = $cateObj->getListCateParent();
    }
}