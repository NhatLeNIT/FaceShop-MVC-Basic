<?php

/**
 * Created by PhpStorm.
 * User: NhatLe
 * Date: 28-May-17
 * Time: 17:48
 */
class HomeController extends BaseController
{
    public function indexAction() {
        $this->data['title'] = 'Bán hàng trực tuyến FaceShop';

        $this->view->load('home', 'User/modules', $this->data);
    }
}