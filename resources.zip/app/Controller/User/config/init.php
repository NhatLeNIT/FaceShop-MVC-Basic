<?php
/**
 * Created by PhpStorm.
 * User: NhatLe
 * Date: 26-May-17
 * Time: 23:05
 */
return array(
    'default_controller'    => 'home', // controller mặc định
    'default_action'        => 'index', // action mặc định
    '404_controller'        => 'error', // controller lỗi 404
    '404_action'            => 'index'  // action lỗi 404
);