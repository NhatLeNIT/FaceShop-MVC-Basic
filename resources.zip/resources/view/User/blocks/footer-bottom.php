<?php
/**
 * Created by PhpStorm.
 * User: NhatLe
 * Date: 28-May-17
 * Time: 18:11
 */
?>
<div class="footer-bottom-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6">
                <div class="copyright">
                    <p>Copyright © <a href="#">NhatLe.Net</a>. All Rights Reserved</p>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6">
                <div class="payment-img">
                    <img src="public/images/icons/payment.png" alt="" />
                </div>
            </div>
        </div>
    </div>
</div>
