<?php
/**
 * Created by PhpStorm.
 * User: NhatLe
 * Date: 28-May-17
 * Time: 18:29
 */
include 'resources/view/User/blocks/slider.php';
?>

