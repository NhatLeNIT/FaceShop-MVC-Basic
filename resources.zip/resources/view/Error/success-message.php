<?php
/**
 * Created by PhpStorm.
 * User: NhatLe
 * Date: 29-May-17
 * Time: 13:09
 */
?>
<div class="alert alert-success alert-dismissible fade in" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
    <div class="success_msg">
        <?php echo $success;?>
    </div>
</div>

