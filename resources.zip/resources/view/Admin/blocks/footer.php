<?php
/**
 * Created by PhpStorm.
 * User: NhatLe
 * Date: 26-May-17
 * Time: 16:15
 */
?>
<footer>
    <div class="pull-right">
        Development by <a href="http://nhatle.net">NhatLe.Net</a>
    </div>
    <div class="clearfix"></div>
</footer>
